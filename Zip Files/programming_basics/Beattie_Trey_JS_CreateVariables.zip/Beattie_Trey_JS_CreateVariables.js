var riderHeight // must be at least 42 inches
var riderAge //must be at least 10 years of age